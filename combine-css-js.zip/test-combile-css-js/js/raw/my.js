

  var myFullpage = new fullpage('#fullpage', {
    anchors: ['firstPage', 'first2Page','secondPage', '3rdPage', '4thPage', '5thPage', '6thPage', '7thPage', '8thPage', '9thPage', '10thPage', '11thPage', '12thPage'],
    sectionsColor: [' #000', ' #000', ' #000', ' #000', ' #000', ' #000', ' #000', ' #000', ' #000', ' #000', ' #000',' #000',' #000'],
    navigation: true,
    navigationPosition: 'left'
    // navigationTooltips: ['First page', 'Second page', 'Third', 'Fourth and last page']
  });
